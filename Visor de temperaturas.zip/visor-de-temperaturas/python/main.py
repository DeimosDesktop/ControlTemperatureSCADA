#VERSION FUNCIONAL
'''from arduino.app_utils import App
from arduino.app_bricks.web_ui import WebUI

ui = WebUI()

def recibir_temperatura(payload):
    # 'payload' es el valor que el servidor espera en la URL
    # Si el servidor espera un JSON, lo recibimos como string y lo procesamos
    print(f"\n📥 [UNO Q] Dato recibido: {payload}")
    
    # Intentamos extraer la temperatura del payload
    # Como el servidor espera un string, asumimos que el atacante enviará solo el número
    try:
        temp = float(payload)
        if temp >= 30.0:
            print("🚨 ¡ALERTA CRÍTICA! Temperatura falsa detectada.")
        elif temp >= 22.0:
            print("🟡 Temperatura elevada (simulada).")
        else:
            print("🟢 Temperatura normal (simulada).")
    except (ValueError, TypeError):
        print("❌ El dato recibido no es un número válido.")
    
    return {"status": "ok", "mensaje": "Dato procesado"}

# Registramos la ruta. El servidor espera un parámetro 'payload' en la URL
ui.expose_api("POST", "/api/temperatura/{payload}", recibir_temperatura)

App.run()'''

#Version WEB
from arduino.app_utils import App
from arduino.app_bricks.web_ui import WebUI

ui = WebUI()

ultima_temperatura = 0.0
estado_alerta = "🟢 Esperando datos..."

# 1. El HTML pedirá los datos a esta ruta (GET)
def obtener_estado():
    return {
        "temperatura": ultima_temperatura,
        "alerta": estado_alerta
    }

# 2. El atacante enviará los datos falsos a esta ruta (POST)
def recibir_temperatura(payload):
    global ultima_temperatura, estado_alerta
    try:
            temp = float(payload)
            ultima_temperatura = temp
            
            if temp >= 30.0:
                estado_alerta = "🚨 ¡ALERTA CRÍTICA! Temperatura falsa detectada."
                print(f"\n📥 [UNO Q] Dato recibido: {temp} °C -> 🚨 ALERTA")
            else:
                estado_alerta = "🟢 Temperatura normal."
                print(f"\n📥 [UNO Q] Dato recibido: {temp} °C -> 🟢 Normal")
    except ValueError:
            print("❌ Dato inválido recibido.")
        
    return {"status": "ok"}

# Registramos las rutas
ui.expose_api("GET", "/api/estado", obtener_estado)
ui.expose_api("POST", "/api/temperatura/{payload}", recibir_temperatura)

App.run()