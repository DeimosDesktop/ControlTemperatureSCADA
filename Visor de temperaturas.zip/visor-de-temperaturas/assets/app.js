// Función que pide los datos a Python
async function actualizarDatos() {
    try {
        // Hacemos una petición GET a nuestra API
        const respuesta = await fetch('/api/estado');
        
        // Si la respuesta no es correcta, lanzamos un error
        if (!respuesta.ok) {
            throw new Error(`Error HTTP: ${respuesta.status}`);
        }
        
        const datos = await respuesta.json();
        
        // Actualizamos los textos en el HTML
        document.getElementById('texto-temperatura').innerText = 
            `Última temperatura recibida: ${datos.temperatura.toFixed(2)} °C`;
            
        document.getElementById('texto-alerta').innerText = datos.alerta;
        
        // Cambiamos el color de fondo según la temperatura
        const cuerpo = document.getElementById('cuerpo');
        if (datos.temperatura >= 30.0) {
            cuerpo.className = 'alerta'; // Se pone rojo
        } else {
            cuerpo.className = 'normal'; // Se pone verde
        }
    } catch (error) {
        console.error("Error al conectar con el servidor:", error);
        // Mostramos el error en la web para diagnosticar
        document.getElementById('texto-alerta').innerText = "⚠️ Error de conexión";
    }
}

// Ejecutamos la función cada 1000 milisegundos (1 segundo)
setInterval(actualizarDatos, 1000);

// Ejecutamos una vez al cargar la página
actualizarDatos();